var app = angular.module("myApp", ["ngRoute"]);

app.config(function($routeProvider) {
	$routeProvider
	.when("/", {
		templateUrl: "index.html"
	})
	.when("/new", {
		templateUrl: "new.html"
	})
	.when("/edit/:id", {
		templateUrl: "edit.html"
	})
	.when("/show/:id", {
		templateUrl: "show.html"
	})
})