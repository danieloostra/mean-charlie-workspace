
// app.controller('showController', ['$scope','friendsFactory', '$routeParams',    $scope.show = function(index) {
//     console.log(index); 
//     friendsFactory.show(index, function (returnedData) {
//       $scope.friends = returnedData;
//       console.log("New Controller Index" + index);
//     });
//    }
// // show();
// }]);