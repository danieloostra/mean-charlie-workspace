
//
var app = require('express')();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
server.listen(process.env.PORT || 8000);

var time = 0;
var id = '';

io.sockets.on('connection', function (socket) {
  	socket.on('location', function (data) {
    	io.sockets.emit('location', data);
  	});

  	io.emit('login');
	socket.on('passVideo', (data) => {
		id = data.id;
		if (time > data.time) {
			data.time = time;
		} else {
			time = data.time;
		}
		socket.emit('final', (data));
	})

	socket.on('updatereq', () => {
		io.emit('login');
	})
});

// For serving static files inside ./client
app.use(require('express').static(__dirname + '/client'));
