module.exports = function Route(app) {
	
}