var mathlib = require('./mathlib')();
mathlib.add(5,4);
mathlib.multiply(3,50);
mathlib.squared(9);
mathlib.random(1,66);